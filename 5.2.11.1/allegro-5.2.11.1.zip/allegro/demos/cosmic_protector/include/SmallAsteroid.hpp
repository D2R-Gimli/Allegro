#ifndef SMALLASTEROID_HPP
#define SMALLASTEROID_HPP

class SmallAsteroid : public Asteroid
{
public:
   SmallAsteroid();
   ~SmallAsteroid();
};

#endif // SMALLASTEROID_HPP

