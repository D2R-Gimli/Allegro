#ifdef __cplusplus
extern "C" {
#endif

bool isMultitaskingSupported(void);

#ifdef __cplusplus
}
#endif

