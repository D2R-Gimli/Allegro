#ifndef		__DEMO_BACK_SCROLLER__
#define		__DEMO_BACK_SCROLLER__

#include <allegro.h>

void init_background(void);
void update_background(void);
void draw_background(BITMAP * canvas);

#endif				/* __DEMO_BACK_SCROLLER__ */
