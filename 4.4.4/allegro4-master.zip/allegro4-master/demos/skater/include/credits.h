#ifndef		__DEMO_CREDITS_H__
#define		__DEMO_CREDITS_H__

#include <allegro.h>

void init_credits(void);
void update_credits(void);
void draw_credits(BITMAP * canvas);
void destroy_credits(void);


#endif				/* __DEMO_CREDITS_H__ */
