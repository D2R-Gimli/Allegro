extern void (*_split_modex_screen_ptr)(int);
