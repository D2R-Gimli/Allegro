Allegro Version: 4.2.0 
