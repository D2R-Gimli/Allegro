Allegro Version: 4.2.0 

File Packaged by Allegro.cc

http://www.allegro.cc/


*** ABOUT ***

	This is a precompiled version of Allegro specifically for MinGW.
	It should be compatible with any recent version of gcc.

*** HOW TO INSTALL ***	

	Because everything is already built, all you need to do is copy
	the files to the correct place. The "lib" and "include" files
	should be placed inside your compiler's directory. This is
	typically C:\MinGW or C:\Dev-CPP. You'll know are looking at the
	right directory if it already contain a "lib" and "include" folder.

	The contents of the "bin" folder (three DLLs) should be placed
	somewhere in your system's PATH. Normally they are put in the
	C:\WINDOWS\SYSTEM32 folder.

*** ADDITIONAL PACKAGES ***

	Do everyone a favor and download both the Allegro support and
	documentation packages. You will get the manual, dozens	of examples,
	and some useful utilities.